// ═════════════════════════════════════════════════════════════
// SOUND PRANK APK - MAIN LOGIC
// ═════════════════════════════════════════════════════════════

class PrankApp {
    constructor() {
        this.audio = null;
        this.isPlaying = false;
        this.tapCount = 0;
        this.wakeLock = null;
        this.audioContext = null;
        
        this.init();
    }
    
    async init() {
        // Setup elements
        this.audio = document.getElementById('prank-audio');
        this.image = document.getElementById('prank-image');
        this.tapOverlay = document.getElementById('tap-overlay');
        this.settingsPanel = document.getElementById('settings-panel');
        
        // Set source
        this.audio.src = PRANK_CONFIG.soundPath;
        this.image.src = PRANK_CONFIG.imagePath;
        
        // Preload
        this.audio.load();
        this.image.onload = () => {
            document.getElementById('loading-screen').classList.add('hidden');
            document.getElementById('main-content').classList.remove('hidden');
        };
        
        // Event listeners
        this.setupEventListeners();
        
        // Setup background persistence
        this.setupBackgroundPersistence();
        
        // Request wake lock
        if (PRANK_CONFIG.backgroundMode.wakeLock) {
            this.requestWakeLock();
        }
    }
    
    setupEventListeners() {
        // Tap overlay - unlock audio
        this.tapOverlay.addEventListener('click', () => {
            this.startPrank();
        });
        
        this.tapOverlay.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.startPrank();
        });
        
        // Secret settings button (5 taps)
        document.getElementById('secret-button').addEventListener('click', () => {
            this.tapCount++;
            if (this.tapCount >= 5) {
                this.openSettings();
                this.tapCount = 0;
            }
            setTimeout(() => this.tapCount = 0, 2000);
        });
        
        // Close settings
        document.getElementById('close-settings').addEventListener('click', () => {
            this.settingsPanel.classList.add('hidden');
        });
        
        // File inputs
        document.getElementById('sound-input').addEventListener('change', (e) => {
            this.handleFileSelect(e, 'sound');
        });
        
        document.getElementById('image-input').addEventListener('change', (e) => {
            this.handleFileSelect(e, 'image');
        });
        
        // Volume slider
        document.getElementById('volume-slider').addEventListener('input', (e) => {
            const vol = e.target.value / 100;
            this.setVolume(vol);
        });
        
        // Any interaction triggers play
        ['click', 'touchstart', 'mousedown', 'keydown', 'scroll'].forEach(evt => {
            document.addEventListener(evt, () => {
                if (!this.isPlaying) this.startPrank();
            }, { once: true });
        });
    }
    
    async startPrank() {
        if (this.isPlaying) return;
        
        // Hide overlay
        this.tapOverlay.classList.add('hidden');
        
        // Create multiple audio instances for redundancy
        this.playAggressive();
        
        this.isPlaying = true;
        
        // Fullscreen
        if (PRANK_CONFIG.display.fullscreen) {
            this.enterFullscreen();
        }
        
        // Hide cursor
        if (PRANK_CONFIG.display.hideCursor) {
            document.body.style.cursor = 'none';
        }
    }
    
    playAggressive() {
        const playAudio = () => {
            // Method 1: HTML5 Audio
            this.audio.volume = PRANK_CONFIG.audio.volume;
            this.audio.play().catch(() => {});
            
            // Method 2: Web Audio API (bypass restriction)
            this.playWebAudio();
            
            // Method 3: Create multiple instances
            for (let i = 0; i < 3; i++) {
                setTimeout(() => {
                    const a = new Audio(PRANK_CONFIG.soundPath);
                    a.volume = PRANK_CONFIG.audio.volume;
                    a.loop = PRANK_CONFIG.audio.loop;
                    a.play().catch(() => {});
                }, i * 50);
            }
        };
        
        playAudio();
        
        // Keep alive
        setInterval(() => {
            if (this.audio.paused) {
                this.audio.play().catch(() => {});
            }
            this.audio.volume = PRANK_CONFIG.audio.volume;
        }, 500);
    }
    
    playWebAudio() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            fetch(PRANK_CONFIG.soundPath)
                .then(r => r.arrayBuffer())
                .then(buffer => this.audioContext.decodeAudioData(buffer))
                .then(audioBuffer => {
                    const source = this.audioContext.createBufferSource();
                    source.buffer = audioBuffer;
                    source.loop = true;
                    
                    const gain = this.audioContext.createGain();
                    gain.gain.value = PRANK_CONFIG.audio.volume;
                    
                    source.connect(gain);
                    gain.connect(this.audioContext.destination);
                    source.start(0);
                });
        } catch(e) {}
    }
    
    setupBackgroundPersistence() {
        if (!PRANK_CONFIG.backgroundMode.enabled) return;
        
        // Override visibility API
        Object.defineProperty(document, 'hidden', {
            get: () => false,
            configurable: true
        });
        
        Object.defineProperty(document, 'visibilityState', {
            get: () => 'visible',
            configurable: true
        });
        
        // Handle visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.maintainAudio();
            }
        });
        
        // Handle blur/focus
        window.addEventListener('blur', () => this.maintainAudio());
        window.addEventListener('pagehide', () => this.maintainAudio());
        
        // Aggressive keepalive
        if (PRANK_CONFIG.backgroundMode.aggressive) {
            setInterval(() => this.maintainAudio(), 300);
        }
    }
    
    maintainAudio() {
        // Resume audio context
        if (this.audioContext && this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
        
        // Play if paused
        if (this.audio.paused) {
            this.audio.play().catch(() => {});
        }
        
        // Force volume
        this.audio.volume = PRANK_CONFIG.audio.volume;
        
        // Create silent oscillator to keep context alive
        try {
            const osc = this.audioContext.createOscillator();
            const gain = this.audioContext.createGain();
            gain.gain.value = 0.001;
            osc.connect(gain);
            gain.connect(this.audioContext.destination);
            osc.start();
            osc.stop(this.audioContext.currentTime + 0.01);
        } catch(e) {}
    }
    
    async requestWakeLock() {
        if ('wakeLock' in navigator) {
            try {
                this.wakeLock = await navigator.wakeLock.request('screen');
                this.wakeLock.addEventListener('release', () => {
                    navigator.wakeLock.request('screen').catch(() => {});
                });
            } catch(e) {}
        }
    }
    
    setVolume(vol) {
        PRANK_CONFIG.audio.volume = vol;
        this.audio.volume = vol;
    }
    
    handleFileSelect(event, type) {
        const file = event.target.files[0];
        if (!file) return;
        
        const url = URL.createObjectURL(file);
        
        if (type === 'sound') {
            PRANK_CONFIG.soundPath = url;
            this.audio.src = url;
            this.audio.load();
            alert('Sound updated! Tap screen to play.');
        } else if (type === 'image') {
            PRANK_CONFIG.imagePath = url;
            this.image.src = url;
        }
        
        this.isPlaying = false;
        this.tapOverlay.classList.remove('hidden');
    }
    
    openSettings() {
        this.settingsPanel.classList.remove('hidden');
    }
    
    enterFullscreen() {
        const elem = document.documentElement;
        if (elem.requestFullscreen) elem.requestFullscreen();
        else if (elem.webkitRequestFullscreen) elem.webkitRequestFullscreen();
        else if (elem.msRequestFullscreen) elem.msRequestFullscreen();
    }
}

// Initialize app
window.addEventListener('load', () => {
    new PrankApp();
});
