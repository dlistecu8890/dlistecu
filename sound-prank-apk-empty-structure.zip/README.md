# 🎵 Sound Prank APK

## Cara Install

### Opsi 1: Buka Langsung di Browser
1. Upload ke Vercel/Netlify
2. Buka link di HP
3. Tap "Add to Home Screen"

### Opsi 2: Build APK (Cordova)
```bash
npm install -g cordova
cordova create prank-app
# Copy file ke www/
cordova platform add android
cordova build android
