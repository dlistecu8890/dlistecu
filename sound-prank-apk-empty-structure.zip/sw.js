const CACHE_NAME = 'prank-app-v1';

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll([
                './',
                './index.html',
                './style.css',
                './app.js',
                './config.js',
                './assets/sounds/sound.mp3',
                './assets/images/prank.jpg'
            ]);
        })
    );
    self.skipWaiting();
});

self.addEventListener('activate', (e) => {
    e.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (e) => {
    e.respondWith(
        caches.match(e.request).then((response) => {
            return response || fetch(e.request);
        })
    );
});

// Keep alive
setInterval(() => {
    self.clients.matchAll().then(clients => {
        clients.forEach(client => client.postMessage('keepalive'));
    });
}, 1000);
