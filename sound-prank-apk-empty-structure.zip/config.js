// ═════════════════════════════════════════════════════════════
// KONFIGURASI APK SOUND PRANK
// ═════════════════════════════════════════════════════════════

const PRANK_CONFIG = {
    // Path ke file (bisa diganti)
    soundPath: 'assets/sounds/sound.mp3',
    imagePath: 'assets/images/prank.jpg',
    
    // Pengaturan audio
    audio: {
        volume: 1.0,        // 0.0 - 1.0 (100%)
        loop: true,         // true = putar ulang terus
        autoplay: true      // true = langsung bunyi
    },
    
    // Pengaturan tampilan
    display: {
        hideCursor: true,           // Sembunyikan kursor
        preventSleep: true,         // Cegah layar mati
        fullscreen: true            // Mode fullscreen
    },
    
    // Background persistence (tetap bunyi saat keluar)
    backgroundMode: {
        enabled: true,
        aggressive: true,           // Mode agresif untuk Android
        wakeLock: true              // Cegah HP sleep
    }
};

// ═════════════════════════════════════════════════════════════
// CARA GANTI SOUND & FOTO:
// 
// METODE 1: Ganti file di folder assets/
//   - Ganti assets/sounds/sound.mp3 dengan file MP3 baru
//   - Ganti assets/images/prank.jpg dengan file gambar baru
//
// METODE 2: Upload via Settings (di APK)
//   - Tap pojok kanan atas 5x untuk buka settings
//   - Pilih file sound/image dari HP
//
// METODE 3: Ganti URL di bawah ini:
// ═════════════════════════════════════════════════════════════

// Uncomment dan ganti jika pakai URL:
// PRANK_CONFIG.soundPath = 'https://link-ke-sound-anda.mp3';
// PRANK_CONFIG.imagePath = 'https://link-ke-gambar-anda.jpg';
